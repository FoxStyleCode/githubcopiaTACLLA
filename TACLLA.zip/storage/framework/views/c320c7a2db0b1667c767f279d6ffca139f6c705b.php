

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="container">

        <?php if(session('danger')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('danger')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Roles de usuario</div>
                    <div class="card-body">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-role')): ?>
                            <div class="row justify-content-end pb-4">
                                <a href="<?php echo e(url('roles/create')); ?>" class="btn btn-success"><i class="fas fa-plus-square"></i></a>
                            </div>
                        <?php endif; ?>
                        <table class="table" id="mitablarole">
                            <thead>
                                <tr>
                                    <td>nombre</td>
                                    <td>nombre de la guardia</td>
                                    <td>acciones</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($role->name); ?></td>
                                    <td><?php echo e($role->guard_name); ?></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('actualizar-role')): ?>
                                        <a href="<?php echo e('/roles/'.$role->id.'/edit'); ?>" class="btn btn-primary"><i class="far fa-edit"></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar-role')): ?>
                                        <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="post" style="display: inline-block">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger"><i class="fas fa-eraser"></i></button>
                                            
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="js/jquery-3.5.1.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>

<script>
    var tabla = $('#mitablarole').DataTable({
        responsive: true,
        autoWidth: true,

        "language": {  
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No hay proyectos cerrados con este nombre",
            "info": "Mostrando página _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtrando de _MAX_ registros totales)",
            "search": "Buscar",
            "paginate": {
            "previous": "Anterior",
            "next": "Siguiente",
            }
            }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/roles/index.blade.php ENDPATH**/ ?>