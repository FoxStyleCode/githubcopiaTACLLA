


<?php $__env->startSection('contenido'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h2>Editar proyecto</h2>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $proyecto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyectos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('proyectos.update', $proyectos->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="num">Numero del proyecto</label>
                                <input type="text" name="num" id="" required class="form-control" autocomplete="off" value="<?php echo e($proyectos->pryct); ?>">
                            </div>
                            <div class="form-group">
                                <label for="fech">Fecha</label>
                                <input type="date" name="fech" id="" required class="form-control" value="<?php echo e($proyectos->fecha); ?>">
                            </div>
                            <div class="form-group">
                                <label for="cli">Cliente</label>
                                <input type="text" name="cli" id="" required class="form-control" autocomplete="off" value="<?php echo e($proyectos->cliente); ?>">
                            </div>
                            <div class="form-group">
                                <label for="nom">Nombre del proyecto</label>
                                <input type="text" name="nom" id="" required class="form-control" autocomplete="off" value="<?php echo e($proyectos->proyecto); ?>">
                            </div>
                            <div class="form-group">
                                <label for="ver">Predio - Vereda</label>
                                <input type="text" name="ver" id="" required class="form-control" autocomplete="off" value="<?php echo e($proyectos->predio); ?>">
                            </div>
                            <div class="form-group">
                                <label for="muni">Municipio</label>
                                <input type="text" name="muni" id="" required class="form-control" autocomplete="off" value="<?php echo e($proyectos->municipio); ?>">
                            </div>
                            <div class="form-group">
                                <label for="name">Tipo de proyecto</label>
                                <select class="form-control" name="tipo" id="">
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($proyectos->tipo_de_proyecto_id==$datos->id): ?>
                                    <option selected value="<?php echo e($datos->id); ?>">
                                        <?php echo e($datos->nombre); ?>

                                    </option>
                                    <?php else: ?>
                                    <option value="<?php echo e($datos->id); ?>">
                                        <?php echo e($datos->nombre); ?>

                                    </option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="justify-content-end">
                                <input class="btn btn-success" type="submit" name="" id="" value="Enviar">
                            </div>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/proyectos/edit.blade.php ENDPATH**/ ?>