


<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h2>editar role</h2>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('roles.update', $roles->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="name">Nombre role</label>
                                <input type="text" name="namerole" id="name" required class="form-control" value="<?php echo e($roles->name); ?>">
                            </div>


                            <div class="form-group">
                                <ul class="list-unstyled">
                                 <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="form-check">
                                 <label class="form-check-label" for="permissions[<?php echo e($permission->id); ?>]">
                                    <!--
                                    En la vista recibimos 2 arrays : "permissions" que contiene TODOS los PERMISOS y "assignedPermisions" que contiene los PERMISOS asignados a cada ROLE
                                    Vamos recorriendo el ARRAY de TODOS los PERMISOS y generando los INPUT CHECKBOX
                                    Si el ID del PERMISO $permission->id se encuenta el array de assignedPermissions ponemos el texto "checked" y si no ""
                                    -->
                                    <input type="checkbox" value="<?php echo e($permission->id); ?>"
                                      name="permissions[]" id="permissions[<?php echo e($permission->id); ?>]"
                                      class="form-check-input"
                                      <?php if(isset($assignedPermissions)): ?>
                                      <?php echo e(in_array($permission->id,$assignedPermissions) ? 'checked':''); ?><?php endif; ?>
                                      ><?php echo e($permission->name); ?>

                                    <em>(</em><em style="color:"><?php echo e($permission->description ? : 'Sin descripción'); ?></em><em>)</em>
                                   </label>
                                  </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                               </div>

                               
                            <div class="justify-content-end">
                                <input class="btn btn-success" type="submit" name="" id="" value="Enviar">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/roles/edit.blade.php ENDPATH**/ ?>