


<?php $__env->startSection('css'); ?>
<style>
    .prue{
        margin: 1px;
    }


</style>
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="container">

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <?php if(session('danger')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('danger')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <div class="row justify-content-center">
            <div class="col-md-16 text-center">
                <div class="card">
                    <div class="card-header">Lista de proyectos</div>
                    <div class="card-body">

                        <div class="d-flex flex-row-reverse bd-highlight">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-tipo-proyecto')): ?>
                            <div class="row justify-content-end ml-1 p-2  bd-highlight">
                                <a class="btn btn-success prue" data-toggle="modal" data-target="#ventanaModelTipo" href="">Configurar tipo</a>
                            </div>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-tareas')): ?>
                            <div class="row justify-content-end ml-1 p-2 bd-highlight">
                                <a class="btn btn-success prue" data-toggle="modal" data-target="#ventanaTareas" href="">Configurar tarea</a>
                            </div>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-proyecto')): ?>
                            <div class="row justify-content-end ml-1 p-2 bd-highlight">
                                <a href="<?php echo e(url('proyectos/create')); ?>" class="btn btn-primary prue">Nuevo proyecto</a>
                            </div>
                            <?php endif; ?>
                          </div>
                          <br>

                        <?php $__env->startSection('content'); ?>
                        <!-- Modal -->
                        <div class="modal fade" id="ventanaModelTipo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Nuevo tipo de proyecto</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                    <guardar-tarea :task="<?php echo e($tipos); ?>"/>
                                </div>     
                            </div>
                            </div>
                        </div>
                        <?php $__env->stopSection(); ?>
                        <!-- Modal -->
                        <div class="modal fade" id="ventanaTareas" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Nueva tarea</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                    
                                    <form action="<?php echo e(url('nuevTarea')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
        
                                    <div class="form-group">
                                        <label for="">Nombre de la tarea</label>
                                        <input type="text"
                                        class="form-control" name="nombretarea" id="" aria-describedby="helpId" placeholder="">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="name">Area</label>
                                        <select class="form-control" name="area" id="">
                                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>">
                                                <?php echo e($value->nombre_area); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                        <button type="submit" class="btn btn-success">Crear</button>
                                        </div>
                                </form>
                                </div>     
                            </div>
                            </div>
                        </div>

                        <table class="table" id="mitablap">
                            <thead>
                                <tr>
                                    <td>Jugador</td>
                                    <td>Numero proyecto</td>
                                    <td>Fecha</td>
                                    <td>Cliente</td>
                                    <td>Nombre proyecto</td>
                                    <td>Predio</td>
                                    <td>Municipio</td>
                                    <td>Tipo de proyecto</td>
                                    <td>Acciones</td>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                <td><?php echo e($datos->name); ?></td>
                                <td><?php echo e($datos->pryct); ?></td>
                                <td><?php echo e($datos->fecha); ?></td>
                                <td><?php echo e($datos->cliente); ?></td>
                                <td><?php echo e($datos->proyecto); ?></td>
                                <td><?php echo e($datos->predio); ?></td>
                                <td><?php echo e($datos->municipio); ?></td>
                                <td><?php echo e($datos->nombre); ?></td>
                                <td class="d-flex">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-proyecto')): ?>
                                    <a class="btn btn-primary prue" href="<?php echo e(url('/proyectos/'.$datos->id. '/edit')); ?>"><i class="far fa-edit"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-tareas')): ?>
                                    <a name="" id="" class="btn btn-warning prue" href="<?php echo e(route('tareas.show', $datos->id)); ?>" role="button"><i class="far fa-eye"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar-proyecto')): ?>
                                    <form action="<?php echo e(route('cerrados.destroy', $datos->id)); ?>" class="formulario-cerrar" method="post">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>

                                        <button type="submit" class="btn btn-danger prue"><i class="far fa-window-close"></i></button>
                                    </form>

                                    
                                    <?php endif; ?>
                                    
                                    <a name="" id="" class="btn btn-info prue" href="<?php echo e(route('links.show', $datos->id)); ?>" role="button"><i class="far fa-file-alt"></i></a>
                                </td>
                               </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        

                    </div>
                </div>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script src="<?php echo e(asset('js/jquery-3.5.1.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>

<script type="text/javascript">
    var tabla = $('#mitablap').DataTable({
        responsive: true,
        autoWidth: true,

        "language": {  
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No hay proyectos cerrados con este nombre",
            "info": "Mostrando página _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtrando de _MAX_ registros totales)",
            "search": "Buscar",
            "paginate": {
            "previous": "Anterior",
            "next": "Siguiente",
            }
            }
        });
</script>

        <?php if(session('eliminar')=='eliminado'): ?>
        <script>
            Swal.fire(
            'Cerrado!',
            'El proyecto ha sido cerrado correctamente.',
            'success'
            ),
            session()->forget('eliminar');
        </script>
        <?php endif; ?>

<script>
    $('.formulario-cerrar').submit(function(e){
        e.preventDefault();

            Swal.fire({
            title: '¿Cerrar el proyecto?',
            text: "Estás seguro que deseas cerrar este proyecto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Cancelar',
            confirmButtonText: 'Si, Cerrar Proyecto!'
            }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        });
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/proyectos/index.blade.php ENDPATH**/ ?>