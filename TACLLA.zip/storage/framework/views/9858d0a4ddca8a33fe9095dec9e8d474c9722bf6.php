


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/stilosprinci.css")); ?>">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Log</div>
                <div class="card-body">
                    <table class="table-primary" id="mitabla" style="width:100%">
                        <thead class="thead-light">
                            <tr>
                                <th>Fecha</th>
                                <th>Hora</th>
                                <th>Usuario</th>
                                <th>Modificación</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($log->fecha); ?></td>
                            <td><?php echo e($log->hora); ?></td>
                            <td><?php echo e($log->usuario); ?></td>
                            <td><?php echo e($log->modificacion); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>  
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.22/b-1.6.5/datatables.min.js"></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.print.min.js')); ?>"></script>
<script>
    var tabla = $('#mitabla').DataTable({
        responsive: true,
        autoWidth: true,
        dom: '<"top"Bf><"top">rt<"bottom"lpi><"clear">',
        
        buttons: [{
        //Botón para Excel
        extend: 'excelHtml5',
        footer: true,
        titleAttr: 'Exportar a excel',
        filename: 'Export_File',
        className: "excel",
        //Aquí es donde generas el botón personalizado
        text: '<button class="btn btn-success prue"><i class="fas fa-file-excel"></i></button>'
        },
        {
        extend: 'pdfHtml5',
        footer: true,
        titleAttr: 'Exportar a PDF',
        filename: 'Reporte_PDF',
        className: "pdf",
        text: '<button class="btn btn-danger prue"><i class="far fa-file-pdf"></i></button>'
        },
        {
        extend: 'csv',
        footer:true,
        titleAttr: 'Exportar a CSV',
        filename: 'Reporte_CSV',
        className: 'csv',
        text: '<button class="btn btn-warning prue"><i class="fas fa-file-csv"></i></button>'
        },
        {
        extend: 'copyHtml5',
        footer: true,
        titleAttr: 'Copiar reporte',
        filename: 'Export_File_copy',
        className: "copy",
        text: '<button class="btn btn-primary prue"><i class="far fa-copy"></i></button>'
        }
        ],

        "language": {  
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No hay registros - lo sentimos",
            "info": "Mostrando página _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtrando de _MAX_ registros totales)",
            "search": "Buscar",
            "paginate": {
            "previous": "Anterior",
            "next": "Siguiente",
            }
            }
    });
</script>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/logs/principal.blade.php ENDPATH**/ ?>