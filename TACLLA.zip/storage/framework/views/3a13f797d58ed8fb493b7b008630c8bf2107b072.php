

<?php $__env->startSection('css'); ?>
    
    
    
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Proyectos cerrados</div>
                <div class="card-body">
                    <table class="table-success" id="mitabla" style="width:100%">
                        <thead>
                            <tr>
                                <td>Jugador</td>
                                <td>Numero proyecto</td>
                                <td>Fecha</td>
                                <td>Cliente</td>
                                <td>Nombre proyecto</td>
                                <td>Predio</td>
                                <td>Municipio</td>
                                <td>Tipo de proyecto</td>
                                <td>Acciones</td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                            <td><?php echo e($datos->player); ?></td>
                            <td><?php echo e($datos->pryct); ?></td>
                            <td><?php echo e($datos->fecha); ?></td>
                            <td><?php echo e($datos->cliente); ?></td>
                            <td><?php echo e($datos->proyecto); ?></td>
                            <td><?php echo e($datos->predio); ?></td>
                            <td><?php echo e($datos->municipio); ?></td>
                            <td><?php echo e($datos->nombre); ?></td>
                            <td>
                                <div class="row">
                                    <div style="margin-right:2px">
                                        <a name="" id="" class="btn btn-warning" href="<?php echo e(route('tareas.show', $datos->id)); ?>" role="button"><i class="far fa-eye"></i></a>
                                    </div>
                                    <div style="margin-left:2px">
                                        <a name="" id="" class="btn btn-info" href="<?php echo e(route('links.show', $datos->id)); ?>" role="button"><i class="far fa-file-alt"></i></a>
                                    </div>
                                </div>
                            </td>
                           </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>  
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="js/jquery-3.5.1.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>

<script>
    var tabla = $('#mitabla').DataTable({
        responsive: true,
        autoWidth: true,

        "language": {  
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No hay proyectos cerrados con este nombre",
            "info": "Mostrando página _PAGE_ de _PAGES_",
            "infoEmpty": "No records available",
            "infoFiltered": "(filtrando de _MAX_ registros totales)",
            "search": "Buscar",
            "paginate": {
            "previous": "Anterior",
            "next": "Siguiente",
            }
            }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/cerrados/index.blade.php ENDPATH**/ ?>