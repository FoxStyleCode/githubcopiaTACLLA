



<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h2>editar usuario</h2>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('usuarios.update', $usuario->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="name">Nombre</label>
                                <input type="text" name="name" id="name" required class="form-control" value="<?php echo e($usuario->name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="email">Correo</label>
                                <input type="text" name="email" id="" required class="form-control" value="<?php echo e($usuario->email); ?>">
                            </div>
                            <div class="form-group">
                                <label for="password">Contraseña</label>
                            <input type="text" name="password" id="" class="form-control" value="">
                            </div>
                            <div class="form-group">
                                <label for="name">Role</label>
                                <select class="form-control" name="role" id="">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($usuario->hasRole($value)): ?>
                                    <option value="<?php echo e($value); ?>" selected><?php echo e($value); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="justify-content-end">
                                <input class="btn btn-success" type="submit" name="" id="" value="Enviar">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>