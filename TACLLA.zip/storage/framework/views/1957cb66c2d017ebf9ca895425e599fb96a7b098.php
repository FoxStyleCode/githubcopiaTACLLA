
<?php $__env->startSection('css'); ?>
<style>
    .accordion {
      background-color: #eee;
      color: #444;
      cursor: pointer;
      padding: 18px;
      width: 100%;
      border: none;
      text-align: left;
      outline: none;
      font-size: 15px;
      transition: 0.4s;
    }
    
    .active, .accordion:hover {
      background-color: #ccc; 
    }
    
    .panel {
      padding: 0 18px;
      display: none;
      background-color: white;
      overflow: hidden;
    }
    </style>
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('contenido'); ?>

<div class="container">
    <?php if(!empty($errors->all())): ?>
    <div class="alert alert-danger">
        <h4 class="is-size-4">Por favor, valida los siguientes errores:</h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($mensaje); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <?php if(session('danger')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('danger')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">Nueva plantilla</div>
            <div class="card-body">
                <div class="d-flex flex-row-reverse bd-highlight">
                <div class="row justify-content-end ml-1 p-2  bd-highlight">
                    <a class="btn btn-success prue" data-toggle="modal" data-target="#ventanaModalAdd" href="">Añadir</a>
                </div>
                </div>
                <h2>Area de plantillas</h2>
                <button class="accordion" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                Mostrar todas las plantillas
                </button>         
                <div class="collapse" id="collapseExample">
                        <br>
                        <div class="row">
                            <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-4">
                                <div class="card">
                                    <img title="titulo-plantilla" alt="Cotización" class="card-img-top w-60" src="/imagenes/<?php echo e($resul->dir); ?>" alt=""/>
                                    <div class="card-body">
                                        <h5 class="card-title $enable-responsive-font-sizes"><?php echo e($resul->nombre_plantilla); ?></h5>
                                        <a target="_blank" href="<?php echo e($resul->link); ?>"><?php echo e($resul->nombre_plantilla); ?></a>
                                        <form action="<?php echo e(route('plantillas.destroy', $resul->id)); ?>" method="post" style="display: inline-block">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <input class="btn btn-danger" type="submit" name="" id="" value="Quitar">
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </div>
                </div>
                <!-- Modal -->
                <div class="modal fade" id="ventanaModalAdd" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Nueva Plantilla</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(url('plantillas')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleFormControlFile1">Imagen identificativa</label>
                                <input type="file" name="file" class="form-control-file" id="exampleFormControlFile1">
                              </div>
                            <div class="form-group">
                              <label for="">Nombre de la plantilla</label>
                              <input type="text"
                                class="form-control" name="namep" id="" aria-describedby="helpId" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="">Enlace de la plantilla</label>
                                <input type="text"
                                  class="form-control" name="enlacep" id="" aria-describedby="helpId" placeholder="">
                              </div>
                            
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                <button type="submit" class="btn btn-success">Agregar</button>
                                </div>
                        </form>
                        </div>     
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/plantillas/index.blade.php ENDPATH**/ ?>