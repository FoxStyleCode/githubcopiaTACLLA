<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!--scripts-->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>" defer></script>

    <!--font awesome-->
    <script src="https://kit.fontawesome.com/7309319a36.js" crossorigin="anonymous"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/stilos.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('css'); ?>
    
</head>
<body>
    
    <div id="app">
        <nav class="navbar navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('leer-usuarios')): ?>
                            <li>
                            <a href="<?php echo e(url('usuarios')); ?>" class="nav-link">Usuarios</a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('leer-roles')): ?>
                            <li>
                                <a href="<?php echo e(url('roles')); ?>" class="nav-link">Roles</a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-proyecto')): ?>
                            <li>
                                <a href="<?php echo e(url('proyectos')); ?>" class="nav-link">Proyectos</a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-log')): ?>
                            <li>
                                <a href="<?php echo e(url('logs')); ?>" class="nav-link">Log</a>
                            </li>
                            <?php endif; ?>
                            
                            <li>
                                <a href="<?php echo e(url('plantillas')); ?>" class="nav-link">Links</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('cerrados')); ?>" class="nav-link">Cerrados</a>
                            </li>
                            
                            <li class="nav-item dropdown">
                                <a class="nav-link" data-toggle="dropdown" href="#">
                                    <i class="far fa-comment"></i>
                                    <span class="badge badge-warning navbar-badge">
                                    <?php if(count(auth()->user()->unreadNotifications)): ?>
                                        <span class="badge badge-warning"><?php echo e(count(auth()->user()->unreadNotifications)); ?></span>
                                    <?php endif; ?>
                                </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                                    <span class="dropdown-header">Notificacion no leidas</span>
                                    <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#" class="dropdown-item">
                                        <i class="fas fa-envelope mr-2"></i> <?php echo e($notification->data['usuario']); ?>

                                        <span class="pull-right text-muted ml-3 text-sm"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="dropdown-divider"></div>
                                    <span class="dropdown-header center">Notificacion leidas</span>
                                    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->readNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <a href="#" class="dropdown-item">
                                        <i class="fas fa-envelope mr-2"></i> <?php echo e($notification->data['usuario']); ?>

                                        <span class="ml-3 pull-right text-muted ml-3 text-sm"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <hr>
                                    <span class="ml-4 pull-right text-muted text-sm">Sin notificaciones leidas</span>
                                    <?php endif; ?>
                        
                                <div class="dropdown-divider"></div>
                                <a href="<?php echo e(route('marcarLeidas')); ?>" class="dropdown-item dropdown-footer">Marcar todas como leidas</a>
                                </div>
                            </li>
                            <?php echo $__env->yieldContent('ItemNa'); ?>

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>  

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <div class="contenido">
        <?php echo $__env->yieldContent('contenido'); ?>
    </div>

    <div class="scripts">
        <?php echo $__env->yieldContent('scripts'); ?>
    </div>

</body>
</html>
<?php /**PATH C:\laragon\www\TACLLA\resources\views/layouts/app.blade.php ENDPATH**/ ?>