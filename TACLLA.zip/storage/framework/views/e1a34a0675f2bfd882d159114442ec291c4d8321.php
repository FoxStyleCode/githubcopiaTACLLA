

<?php $__env->startSection('css'); ?>

<style>
    .thead-green {
      background-color: rgb(0, 99, 71);
      color: white;
    }
</style>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="container">

        <?php if(session('danger')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('danger')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <div class="row justify-content-center">
            <div class="col-md-10 text-center">
                <div class="card">
                    <div class="card-header">Todos los enlaces</div>
                    <div class="card-body">  
                        <div class="table-responsive">      
                        <table class="table table-striped">
                            <thead class="thead-green">
                                <tr>
                                    <td>Nombre de la tarea</td>
                                    <td>Enlace</td>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                <td><?php echo e($datos->nombre_tarea); ?></td>
                                <?php if(isset($datos->enlace)): ?>
                                <td><a target="_blank" href="<?php echo e($datos->enlace); ?>">Revisar archivo</a></td>
                                <?php else: ?>

                                <?php endif; ?>
                               </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/links/index.blade.php ENDPATH**/ ?>