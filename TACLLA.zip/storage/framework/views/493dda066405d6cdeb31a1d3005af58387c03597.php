

<style>
    .prue{
        
        border-radius: 10px;
    }

    .ctado:hover{
        opacity: 0.9;
    }
</style>

<?php $__env->startSection('contenido'); ?>
    <div class="container">

        <?php if(session('danger')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('danger')); ?>

        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Tareas</div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td class="active">Proyecto</td>
                                    <td class="active">Tarea</td>
                                    <td class="active">Area</td>
                                    <td class="active">Estado</td>
                                    <td class="active">Persona</td>
                                    <td class="active">Asignar</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($result->proyecto); ?></td>
                                    <td data-toggle="modal" data-target="#ventanaLink<?php echo e($result->id); ?>" href=""><?php echo e($result->nombre_tarea); ?></td>
                                    <td><?php echo e($result->nombre_area); ?></td>
                                    <?php if($result->nombre_estado == "programado"): ?>
                                    <td class="ctado" data-toggle="modal" data-target="#ventanaModel<?php echo e($result->id); ?>" style="background-color: #EC7063; border-radius:5px; color: white; text-align: center"><?php echo e($result->nombre_estado); ?></td>
                                    <?php elseif($result->nombre_estado == "proceso"): ?>
                                    <td class="ctado" data-toggle="modal" data-target="#ventanaModel<?php echo e($result->id); ?>" style="background-color: #F5B041; border-radius:5px; color: white; text-align: center"><?php echo e($result->nombre_estado); ?></td>
                                    <?php else: ?> 
                                    <td class="ctado" data-toggle="modal" data-target="#ventanaModel<?php echo e($result->id); ?>" style="background-color:#58D68D; border-radius:5px; color: white; text-align: center"><?php echo e($result->nombre_estado); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($result->name); ?></td>
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('actualizar-tareas')): ?>
                                        <td><a class="btn btn-primary prue" data-toggle="modal" data-target="#ventana<?php echo e($result->id,$result->nombre_tarea); ?>" href=""><i class="far fa-edit"></i></a>
                                            <!-- Modal -->
                                            <div class="modal fade" id="ventana<?php echo e($result->id,$result->nombre_tarea); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Asignar tarea</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        
                                                        <form action="<?php echo e(route('tareas.update', $result->proyecto_id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <input type="text" hidden name="tareaid" value="<?php echo e($result->id); ?>">
                                                        
                                                        <div class="form-group">
                                                            <label for="name">Usuarios</label>
                                                            <select class="form-control" name="tipo" id="">
                                                                <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($us->id); ?>">
                                                                    <?php echo e($us->name); ?>

                                                                </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                            <button type="submit" class="btn btn-success">Asignar</button>
                                                            </div>

                                                    </form>
                                                    </div>
                                                    
                                                </div>
                                                </div>
                                            </div>
                                        </td>
                                        <?php endif; ?>
                            
                                        
                                        <td>
                                            <!-- Modal -->
                                            <div class="modal fade" id="ventanaLink<?php echo e($result->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Linkear</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        
                                                        <form action="<?php echo e(route('links.update', $result->proyecto_id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>

                                                        <input type="text" name="tarea_id" hidden value="<?php echo e($result->id); ?>">
                                                        <div class="form-group">
                                                            <label for="">Enlace</label>
                                                            <input type="text"
                                                              class="form-control" name="enlac" id="" aria-describedby="helpId" placeholder="">
                                                          </div>
                                                       
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                            <button type="submit" class="btn btn-success">Añadir</button>
                                                            </div>
                                                    </form>
                                                    </div>   
                                                </div>
                                                </div>
                                            </div>
                                        </td>

                                        
                                        <?php if(isset($result->enlace)): ?>
                                        <td><a name="" id="" target="_blank" href="<?php echo e($result->enlace); ?>" class="btn btn-warning prue" role="button"><i class="far fa-file-word"></i></a></td>
                                        <?php else: ?>
                                        
                                        <?php endif; ?>


                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('actualizar-estado')): ?>
                                        <td>
                                            <!-- Modal -->
                                            <div class="modal fade" id="ventanaModel<?php echo e($result->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Cambiar estados</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        
                                                        <form action="<?php echo e(route('estados.update', $result->proyecto_id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <input type="text" hidden name="tarea_id" value="<?php echo e($result->id); ?>">
                                                        <input type="" hidden name="nameEs" value="">

                                                        <div class="form-group">
                                                            <label for="name">Estados</label>
                                                            <select class="form-control" name="est" id="">
                                                                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $es): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($es->id); ?>">
                                                                    <span id="nameS"><?php echo e($es->nombre_estado); ?></span>
                                                                </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                            <button type="submit" class="btn btn-success">Cambiar</button>
                                                            </div>

                                                    </form>
                                                    </div>
                                                    
                                                </div>
                                                </div>
                                            </div>
                                        </td>
                                        <?php endif; ?>      
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TACLLA\resources\views/tareas/index.blade.php ENDPATH**/ ?>