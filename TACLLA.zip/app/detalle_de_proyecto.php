<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class detalle_de_proyecto extends Model
{
    //
}
